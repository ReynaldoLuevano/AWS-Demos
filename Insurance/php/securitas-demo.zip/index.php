<?php
$environment = getenv('APP_ENV') ?: 'production';
$timestamp = date('Y-m-d H:i:s');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Securitas Demo – AWS Elastic Beanstalk</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background: #f4f4f4;
            color: #333;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        header {
            background: #c8102e;
            color: white;
            padding: 18px 40px;
            display: flex;
            align-items: center;
            gap: 16px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        }
        header svg { flex-shrink: 0; }
        header h1 { font-size: 1.4rem; font-weight: 600; letter-spacing: 1px; }
        header span { font-size: 0.85rem; opacity: 0.85; margin-left: auto; }
        .main {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px 20px;
        }
        .card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 24px rgba(0,0,0,0.10);
            padding: 48px 56px;
            max-width: 640px;
            width: 100%;
            text-align: center;
        }
        .badge {
            display: inline-block;
            background: #e8f5e9;
            color: #2e7d32;
            font-size: 0.78rem;
            font-weight: 700;
            letter-spacing: 1.5px;
            text-transform: uppercase;
            padding: 5px 14px;
            border-radius: 20px;
            margin-bottom: 22px;
            border: 1px solid #a5d6a7;
        }
        .status-icon {
            font-size: 3.5rem;
            margin-bottom: 16px;
        }
        h2 {
            font-size: 1.7rem;
            color: #c8102e;
            margin-bottom: 10px;
        }
        p.subtitle {
            color: #666;
            font-size: 1rem;
            margin-bottom: 32px;
        }
        .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 14px;
            margin-bottom: 32px;
            text-align: left;
        }
        .info-item {
            background: #f8f8f8;
            border-radius: 8px;
            padding: 14px 18px;
            border-left: 3px solid #c8102e;
        }
        .info-item label {
            font-size: 0.72rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: #999;
            display: block;
            margin-bottom: 4px;
        }
        .info-item span {
            font-size: 0.95rem;
            font-weight: 600;
            color: #333;
        }
        .info-item span.ok { color: #2e7d32; }
        .divider {
            border: none;
            border-top: 1px solid #eee;
            margin: 28px 0;
        }
        .footer-note {
            font-size: 0.82rem;
            color: #aaa;
        }
        footer {
            background: #222;
            color: #aaa;
            text-align: center;
            padding: 16px;
            font-size: 0.8rem;
        }
        footer strong { color: #fff; }
    </style>
</head>
<body>

<header>
    <!-- Securitas-style shield icon -->
    <svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M18 3L4 9v10c0 8.5 6 16.5 14 18.5C26 35.5 32 27.5 32 19V9L18 3z" fill="white" fill-opacity="0.2" stroke="white" stroke-width="2"/>
        <path d="M12 18l4 4 8-8" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
    <h1>SECURITAS – Demo App</h1>
    <span>AWS Elastic Beanstalk</span>
</header>

<div class="main">
    <div class="card">
        <div class="badge">✔ Deployment Successful</div>
        <div class="status-icon">🚀</div>
        <h2>Application is Running</h2>
        <p class="subtitle">
            This PHP placeholder confirms your AWS Elastic Beanstalk<br>
            environment is correctly configured and operational.
        </p>

        <div class="info-grid">
            <div class="info-item">
                <label>PHP Version</label>
                <span class="ok"><?php echo phpversion(); ?></span>
            </div>
            <div class="info-item">
                <label>Server Time</label>
                <span><?php echo $timestamp; ?></span>
            </div>
            <div class="info-item">
                <label>Environment</label>
                <span><?php echo htmlspecialchars($environment); ?></span>
            </div>
            <div class="info-item">
                <label>Server Software</label>
                <span><?php echo htmlspecialchars($_SERVER['SERVER_SOFTWARE'] ?? 'Apache/nginx'); ?></span>
            </div>
            <div class="info-item">
                <label>Host</label>
                <span><?php echo htmlspecialchars($_SERVER['HTTP_HOST'] ?? 'localhost'); ?></span>
            </div>
            <div class="info-item">
                <label>Status</label>
                <span class="ok">HTTP 200 OK</span>
            </div>
        </div>

        <hr class="divider">

        <p class="footer-note">
            This is a technical demo placeholder for internal validation purposes.<br>
            Replace <code>index.php</code> with your production application files.
        </p>
    </div>
</div>

<footer>
    <strong>Securitas Demo</strong> &nbsp;|&nbsp; Deployed on AWS Elastic Beanstalk &nbsp;|&nbsp;
    PHP <?php echo phpversion(); ?> &nbsp;|&nbsp; <?php echo date('Y'); ?>
</footer>

</body>
</html>
